<h1>Email Verification Mail</h1>

Please verify your email with bellow link:
<a href="<?php echo e(route('user.verify.email', $token)); ?>">Verify Email</a>
<?php /**PATH C:\Users\Viktar\Desktop\Programming\vue_projects\traveller_app_backend\resources\views/emails/emailVerificationEmail.blade.php ENDPATH**/ ?>
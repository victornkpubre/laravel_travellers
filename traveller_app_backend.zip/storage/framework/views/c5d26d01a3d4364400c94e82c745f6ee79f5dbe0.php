[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Users\Viktar\Desktop\Programming\vue_projects\traveller_app_backend\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card mt-2">
                <div class="card-header"><?php echo e(__('Welcome')); ?> </div>

                <div class="card-body">
                    <?php if(isset($message)): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
            <a href="<?php echo e(route('dashboard')); ?>">
                <div class="row m-0">
                    <div class="btn btn-block mb-4 w-75 mx-auto mt-4" style="background-color: #5d69b3;">

                            <button type="button" class="btn" style= "color:rgb(255, 255, 255)" >
                                Dashboard
                            </button>

                    </div>
                </div>
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Viktar\Desktop\Programming\vue_projects\traveller_app_backend\resources\views/home.blade.php ENDPATH**/ ?>